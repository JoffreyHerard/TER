#include<iostream>
using namespace std;
int main()
{
	std::cout << "HelloWorld";
	return 0;
}
