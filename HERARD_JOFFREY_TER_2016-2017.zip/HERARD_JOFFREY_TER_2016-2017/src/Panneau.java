import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Graphics;
import java.awt.Image;

@SuppressWarnings({ "serial", "unused" })
public class Panneau extends JPanel {
	  public void paintComponent(Graphics g){
	          
	  }               
}