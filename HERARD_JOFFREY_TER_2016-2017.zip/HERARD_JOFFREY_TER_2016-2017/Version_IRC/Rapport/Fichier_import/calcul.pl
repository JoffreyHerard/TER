#!/usr/bin/perl
use v5.14;

exit $ARGV[0] +$ARGV[1] ;

